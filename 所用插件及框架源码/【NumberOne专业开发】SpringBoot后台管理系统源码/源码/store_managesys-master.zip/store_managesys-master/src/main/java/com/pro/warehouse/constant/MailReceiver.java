package com.pro.warehouse.constant;

public class MailReceiver {
    public static String receiver = "test@szlydwl.com";
}
