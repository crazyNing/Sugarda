package com.pro.warehouse.dao;

import org.springframework.stereotype.Repository;

@Repository
public interface MateriaContarstRepository {
}
