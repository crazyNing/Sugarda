package com.pro.warehouse.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * 获取对象中属性的值并返回list
 */
public class CommonUtil<T> {

}
